"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import axios from "axios";

import { authKeys, categoryKeys } from "@/src/hooks/useCategory";
import { getCurrentUser, loginUser } from "@/src/lib/auth";
import type { ApiErrorBody } from "@/src/types/auth";

const loginSchema = z.object({
  email: z
    .string()
    .trim()
    .min(1, "Email address is required.")
    .email("Enter a valid email address."),
  password: z.string().min(1, "Password is required."),
});

type LoginFormValues = z.infer<typeof loginSchema>;

function getErrorMessage(error: unknown): string {
  if (axios.isAxiosError<ApiErrorBody>(error)) {
    const data = error.response?.data;

    if (typeof data?.detail === "string") return data.detail;

    if (Array.isArray(data?.non_field_errors)) {
      return data.non_field_errors.join(" ");
    }

    if (data && typeof data === "object") {
      const messages = Object.entries(data)
        .filter(([key]) => key !== "detail" && key !== "non_field_errors")
        .flatMap(([, value]) =>
          Array.isArray(value)
            ? value.filter((item): item is string => typeof item === "string")
            : typeof value === "string"
              ? [value]
              : [],
        );

      if (messages.length) return messages.join(" ");
    }

    if (!error.response) {
      return "Cannot reach the server. Check that the Django backend is running.";
    }

    if (error.response.status === 401) {
      return "Invalid email or password. Please try again.";
    }

    if (error.response.status === 429) {
      return "Too many attempts. Please wait a moment and try again.";
    }

    return "Login failed. Please check your details and try again.";
  }

  return "Something went wrong. Please try again.";
}

export default function LoginPage() {
  const router = useRouter();
  const queryClient = useQueryClient();

  const [showPassword, setShowPassword] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const mutation = useMutation({
    mutationFn: loginUser,

    onSuccess: async () => {
      try {
        const user = await getCurrentUser();

        queryClient.setQueryData(authKeys.me, user);

        await queryClient.invalidateQueries({
          queryKey: categoryKeys.all,
        });
      } catch (error) {
        // The login request already succeeded. Don't incorrectly tell the
        // user their credentials failed because the profile request failed.
        console.error("Could not refresh the authenticated user:", error);
      } finally {
        router.replace("/products");
        router.refresh();
      }
    },
  });

  const onSubmit = (values: LoginFormValues) => {
    mutation.reset();

    mutation.mutate({
      email: values.email.trim(),
      password: values.password,
    });
  };

  return (
    <main className="bg-page flex min-h-screen items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg sm:mx-auto">
        <section className="bg-card border-line rounded-card shadow-card border p-6 sm:p-8">
          <header className="mb-7 text-center">
            <div className="mb-5 flex items-center justify-center">
              <Link href="/" className="font-logo text-logo text-2xl">
                LAUNCHAFRICA
              </Link>
            </div>

            <h1 className="text-main text-2xl font-bold">Welcome back</h1>

            <p className="text-soft mt-2 text-sm leading-6">
              Sign in to discover, build, and launch great ideas.
            </p>
          </header>

          <div className="divider my-6">
            <span className="text-soft text-xs">SIGN IN WITH EMAIL</span>
          </div>

          <form
            onSubmit={handleSubmit(onSubmit)}
            className="space-y-5"
            noValidate
          >
            <div>
              <label
                htmlFor="email"
                className="text-main mb-2 block text-sm font-semibold"
              >
                Email address
              </label>

              <input
                id="email"
                type="email"
                autoComplete="email"
                placeholder="you@example.com"
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? "email-error" : undefined}
                {...register("email")}
                className="input-box rounded-pill w-full px-4 py-3"
              />

              {errors.email && (
                <p
                  id="email-error"
                  role="alert"
                  className="text-error mt-1 text-sm"
                >
                  {errors.email.message}
                </p>
              )}
            </div>

            <div>
              <div className="mb-2 flex items-center justify-between gap-3">
                <label
                  htmlFor="password"
                  className="text-main block text-sm font-semibold"
                >
                  Password
                </label>

                <Link
                  href="/forgot-password"
                  className="text-soft text-sm font-semibold underline underline-offset-2 hover:opacity-80"
                >
                  Forgot password?
                </Link>
              </div>

              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  placeholder="Enter your password"
                  aria-invalid={Boolean(errors.password)}
                  aria-describedby={
                    errors.password ? "password-error" : undefined
                  }
                  {...register("password")}
                  className="input-box rounded-pill w-full px-4 py-3 pr-20"
                />

                <button
                  type="button"
                  onClick={() => setShowPassword((current) => !current)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  aria-pressed={showPassword}
                  className="text-soft hover:text-main absolute inset-y-0 right-4 my-auto text-sm font-semibold"
                >
                  {showPassword ? "Hide" : "Show"}
                </button>
              </div>

              {errors.password && (
                <p
                  id="password-error"
                  role="alert"
                  className="text-error mt-1 text-sm"
                >
                  {errors.password.message}
                </p>
              )}
            </div>

            {mutation.isError && (
              <p
                role="alert"
                aria-live="polite"
                className="text-error bg-input rounded-card p-3 text-sm"
              >
                {getErrorMessage(mutation.error)}
              </p>
            )}

            <button
              type="submit"
              disabled={mutation.isPending}
              className="btn-main rounded-pill w-full px-4 py-3 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {mutation.isPending ? "Signing in…" : "Sign in"}
            </button>
          </form>

          <div className="divider my-6">
            <span className="text-soft text-xs">NEW TO LAUNCHAFRICA?</span>
          </div>

          <p className="text-soft text-center text-sm">
            Don&apos;t have an account?{" "}
            <Link
              href="/register"
              className="text-main font-bold hover:opacity-80"
            >
              Create account
            </Link>
          </p>
        </section>

        <p className="text-soft mt-6 text-center text-xs">
          Discover. Build. Launch. Grow.
        </p>
      </div>
    </main>
  );
}
